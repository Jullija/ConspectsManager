from django.core.management.base import BaseCommand

from conspects.models import Edition
from conspects.models.course import Course
from conspects.models.file import File
import os

class Command(BaseCommand):
    help = 'Initializes the database with some data'

    def handle(self, *args, **options):

        ASD = Course.objects.create(name="Algorytmy i struktury danych")
        SYSOPY = Course.objects.create(name="Systemy operacyjne")

        # Editions
        ASD_2024 = Edition.objects.create(course=ASD, year=2024, name="Edycja 2024")
        ASD_2025 = Edition.objects.create(course=ASD, year=2025, name="Edycja 2025")
        SYSOPY_2024 = Edition.objects.create(course=SYSOPY, year=2024, name="Edycja 2024")

        # Folders
        grafy = ASD_2024.root_folder.add_folder("Grafy")
        algorithms = grafy.add_folder("Algorithms")  # New nested folder under Grafy
        zadania = grafy.add_folder("zadania")
        teoria = grafy.add_folder("teoria")
        przyklady = grafy.add_folder("przykłady")
        dynamiki = ASD_2024.root_folder.add_folder("Dynamiki")

        kolejny_folder_w_teorii = teoria.add_folder("Kolejny folder w teorii")
        # Files in 'teoria'
        # teoria.add_file(name="wstęp", extension="pdf", content=b"PDF content for wstep")
        teoria.add_file(name="File1", extension="txt", content="Dzień dobry!".encode())

        # Sample Markdown
        with open("conspects/management/commands/sample_markdown.md", "r") as f:
            content = f.read()
        sample_file = File.objects.create(name="SampleFile", extension="md", content=content.encode(), created_at="2022-01-01 12:00:00", folder=teoria)
        file_paths = {
            "image1.png": os.path.join("conspects/management/commands", "image1.png"),
            "image2.jpg": os.path.join("conspects/management/commands", "image2.jpg"),
            "samplepdf.pdf": os.path.join("conspects/management/commands", "samplepdf.pdf"),
            "text.txt": os.path.join("conspects/management/commands", "text.txt"),
            "mark.md": os.path.join("conspects/management/commands", "mark.md"),
        }

        for file_name, file_path in file_paths.items():
            with open(file_path, 'rb') as file:
                binary_content = file.read()
                extension = file_name.split('.')[-1]
                name = file_name.rsplit('.', 1)[0]
                # Assuming 'folder' is where you want to save this file
                # You may need to adjust based on your actual model relationships and attributes
                File.objects.create(name=name, extension=extension, created_at="2022-01-01 12:00:00", content=binary_content, folder=teoria)

        file_paths_2 = {
            "movie.mp4": os.path.join("conspects/management/commands", "movie.mp4"),
            "moovie.mp4": os.path.join("conspects/management/commands", "moovie.mp4"),
        }

        for file_name, file_path in file_paths_2.items():
            with open(file_path, 'rb') as file:
                binary_content = file.read()
                extension = file_name.split('.')[-1]
                name = file_name.rsplit('.', 1)[0]
                # Assuming 'folder' is where you want to save this file
                # You may need to adjust based on your actual model relationships and attributes
                File.objects.create(name=name, extension=extension, created_at="2022-01-01 12:00:00", content=binary_content, folder=kolejny_folder_w_teorii)

        file_paths_3 = {
            "ggif.gif": os.path.join("conspects/management/commands", "ggif.gif"),
        }
        for file_name, file_path in file_paths_3.items():
            with open(file_path, 'rb') as file:
                binary_content = file.read()
                extension = file_name.split('.')[-1]
                name = file_name.rsplit('.', 1)[0]
                # Assuming 'folder' is where you want to save this file
                # You may need to adjust based on your actual model relationships and attributes
                File.objects.create(name=name, extension=extension, created_at="2022-01-01 12:00:00",
                                    content=binary_content, folder=grafy)

